// (f puis tab
(function($) {
	// POUR TESTER LE CHARGEMENT JQUERY
	// alert('test');
	$('#icon').click(function(e){
		e.preventDefault();
		$('body').toggleClass('with-menu');
	})
	// A AJOUTER APRES LA CREATION DE SITE-CACHE
	$('#site-cache').click(function(e){
		$('body').removeClass('with-menu');
	})
	$('.menu li').click(function(e){
		$('.menu .active').removeClass('active');
        $(this).addClass('active');
		$('body').removeClass('with-menu');
	})
	// 
})(jQuery);
// RETOUR AU CSS